package com.smart.scm.entities;

public class User {

}
