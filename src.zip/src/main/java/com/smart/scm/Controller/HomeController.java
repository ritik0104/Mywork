package com.smart.scm.Controller;


@RestController
public class HomeController {

    @GetMapping("/home")
    public String Home(Model model){
        model.addAttribute("title","Home-SCM")
        return "Home";
    }

    @GetMapping("/about")
    public String About(Model model){
        model.addAttribute("title","About-SCM")
    }

    @GetMapping("/signup")
    public String About(Model model){
        model.addAttribute("title","Signp-SCM")
    }

}
